# Portfolio AILA LEINAF

Site portfolio responsive réalisé en HTML, CSS et JavaScript.

## Personnalisation avant publication
1. Ouvre `index.html`.
2. Remplace `ton.email@example.com` par ton adresse e-mail.
3. Vérifie les compétences affichées et retire celles que tu ne maîtrises pas encore.
4. Remplace les projets d'exemple par tes vrais projets et ajoute les liens vers tes dépôts GitHub.
5. Si tu veux, ajoute une photo professionnelle dans le dossier puis adapte la section d'accueil.

## Aperçu local
Ouvre `index.html` dans un navigateur. Aucun outil de compilation n'est nécessaire.

## Publier gratuitement avec GitHub Pages
1. Crée un compte sur GitHub si tu n'en as pas.
2. Crée un dépôt public, par exemple `aila-leinaf-portfolio`.
3. Envoie les fichiers `index.html`, `style.css` et `script.js` dans le dépôt.
4. Dans le dépôt, ouvre **Settings → Pages**.
5. Dans **Build and deployment**, choisis **Deploy from a branch**, puis `main` et `/ (root)`, et enregistre.
6. Après le déploiement, GitHub affichera l'adresse publique de ton site dans la section Pages.

Note : les compétences, projets et services sont des exemples de présentation. Mets-les à jour pour qu'ils reflètent fidèlement ton expérience.
